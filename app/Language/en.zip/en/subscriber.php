<?php

// override core en language system validation or define your own en language validation message
return [
    'subscriber_list'=>'Subscriber List',
    'coming_soon'=>'Coming Soon',
    'email_address'=>'Email Address',
    'date'=>'Date',
    'time'=>'Time',
    'action'=>'Action',


];
