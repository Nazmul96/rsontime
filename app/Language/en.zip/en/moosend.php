<?php

// override core en language system validation or define your own en language validation message
return [
    'moosend_settings'=>'Moosend settings',
    'coming_soon'=>'Coming Soon',
    'choose_list'=>'Choose list',
    'api_keys'=>'Api Keys',
    'submit'=>'submit'


];