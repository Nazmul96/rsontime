<?php

// override core en language system validation or define your own en language validation message
return [
    'mailchimp_settings'=>'mailchimp settings',
    'coming_soon'=>'Coming Soon',
    'choose_list'=>'Choose list',
    'api_keys'=>'Api Keys',
    'submit'=>'submit'


];