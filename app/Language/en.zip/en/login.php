<?php

// override core en language system validation or define your own en language validation message
return [
    'welcome_back'=>'Welcome Back !',
    'sign_in_continue'=>'Sign in to continue to Upzet.',
    'email'=>'Email',
    'password'=>'Password',
    'remember_me'=>'Remember me',
    'forgot_password'=>'Forgot your password?',
    'log_in'=>'Log In',
    //'account'=>"Don't have an account ?",
    'coming_soon'=>'Coming Soon. Crafted with',
    'rs_software'=>'by RsSoftware'

];