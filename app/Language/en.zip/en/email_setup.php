<?php

// override core en language system validation or define your own en language validation message
return [
    'email_setup'=>'Email Setup',
    'email_sent_from_name'=>'Email sent from name',
    'email_sent_from_email'=>'Email sent from email',
    'supported_mail_services'=>'Supported mail services',
    'smtp_host'=>'SMTP host',
    'port'=>'Port',
    'password_to_access'=>'Password to access',
    'encryption_type'=>'Encryption type'


];
