<?php

// override core en language system validation or define your own en language validation message
return [
    'menu'=>'Menu',
    'dashbaord'=>'Dashbaord',
    'subscriber_list'=>'Subscriber List',
    'counter'=>'Counter',
    'page'=>'Page',
    'create_page'=>'Create Page',
    'about_us'=>'About Us',
    'contact_us'=>'Contact US',
    'add_gallery_image'=>'Add Gallery Image',
    'email_setup'=> 'Email Setup',
    'settings'=>'Settings',
    'visitor_report'=>'Visitor Report',
    'mailchimp_settings'=>'Mailchimp Settings',
    'get_response'=>'Get Response Settings',
    'moosend_settings'=>'moosend Settings',
    'log_out'=>'Log Out',
    'rsontime'=>'Rsontime',
    'total_subscriber'=>'Total Subscriber',
    'total_visitors'=>'Total Visitors',
    'subscriber'=>'Subscriber',
    'total_view'=>'Total View',
    'overview'=>'Overview'

];