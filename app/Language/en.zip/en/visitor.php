<?php

// override core en language system validation or define your own en language validation message
return [
    'visitors_report'=>'Visitors Report',
    'coming_soon'=>'Coming Soon',
    'from'=>'From',
    'to'=>'To',
    'search'=>'Search',
    'server_ip'=>'Server IP',
    'browser'=>'Browser',
    'date'=>'Date',
    'time'=>'Time'


];
