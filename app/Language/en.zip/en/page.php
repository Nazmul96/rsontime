<?php

// override core en language system validation or define your own en language validation message
return [
    'create_page'=>'Create Page',
    'coming_soon'=>'Coming Soon',
    'create_page_details'=>'Create Page Details',
    'page_title'=>'Page Title',
    'page_description'=>'Page Description',
    'save_settings'=>'Save settings',
    'about_us'=>'About Us',
    'about_us_details'=>'About Us Details',
    'contact_us'=>'Contact Us',
    'contact_us_details'=>'Contact Us Details',
    'email_address1'=>'Email Address 1',
    'email_address2'=>'Email Address 2',
    'phone_number1'=>'Phone Number 1',
    'phone_number2'=>'Phone Number 2',
    'address'=>'Address',
    'contact_frontend_google_form'=>'Contact Frontend Google map enable/disable',
    'website_url'=>'Website url',
    'contact_recapcha'=>'Contact Recapcha eable/disable',
    'site_key'=>'Site Key',
    'secret_key'=>'Secret Key',
    'add_gallery_image'=>'Add Gallery Image',
    'gallery_image'=>'Gallery Image',
    'upload_images'=>'Upload Images',
    'gallery'=>'Gallery----'
   
];
