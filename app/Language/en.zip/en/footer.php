<?php

// override core en language system validation or define your own en language validation message
return [
    'coming_soon'=>'© Coming Soon.',
    'crafted_with'=>'Crafted with',
    'by_rssoftware'=>'by RsSoftware'


];
